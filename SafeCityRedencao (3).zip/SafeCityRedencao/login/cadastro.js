async function handleFormSubmit(event) {
    event.preventDefault();  // Impede o envio tradicional do formulário

    const dataNascimento = document.getElementById('data_nascimento').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const cpf = document.getElementById('cpf').value;

    // Verificação de campos obrigatórios
    if (!dataNascimento || !email || !password || !confirmPassword || !cpf) {
        alert("Por favor, preencha todos os campos.");
        return;
    }

    // Validação de CPF (11 dígitos numéricos)
    const cpfRegex = /^\d{11}$/;
    if (!cpfRegex.test(cpf)) {
        alert("CPF inválido! Deve conter 11 dígitos numéricos.");
        return;
    }

    // Verifica se as senhas coincidem
    if (password !== confirmPassword) {
        alert("As senhas não coincidem!");
        return;
    }

    // Envia os dados de cadastro para o backend
    try {
        const response = await fetch('http://localhost:3000/cadastro', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                data_nascimento: dataNascimento,
                email: email,
                password: password,
                confirmPassword: confirmPassword,
                cpf: cpf,
            }),
        });

        const data = await response.json();

        if (response.ok) {
            alert(data.message || "Cadastro realizado com sucesso!");
            window.location.href = 'login.html';  // Redireciona para a página de login
        } else {
            alert(data.message || "Erro ao realizar o cadastro.");
        }
    } catch (error) {
        console.error("Erro ao enviar os dados:", error);
        alert("Erro ao realizar o cadastro. Tente novamente mais tarde.");
    }
}
