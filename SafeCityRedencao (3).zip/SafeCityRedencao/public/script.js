// ========== TEMA ==========
const botaoTema = document.getElementById('btn-tema');
const iconeTema = document.getElementById('icone-tema');

botaoTema.addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');
  if (document.body.classList.contains('dark-mode')) {
    iconeTema.src = 'assets/icons/sun.png';
    iconeTema.alt = 'Modo Claro';
  } else {
    iconeTema.src = 'assets/icons/moon.png';
    iconeTema.alt = 'Modo Escuro';
  }
});

// ========== MAPA ==========
const map = L.map('map').setView([-8.0517, -34.8770], 13);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '© OpenStreetMap contributors'
}).addTo(map);
L.marker([-8.0517, -34.8770]).addTo(map)
  .bindPopup('Você está aqui!')
  .openPopup();

// ========== BUSCA DE ENDEREÇO ==========
document.getElementById('searchButton').addEventListener('click', () => {
  const query = document.getElementById('searchInput').value;
  if (!query) return;

  fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`)
    .then(response => response.json())
    .then(data => {
      if (data.length > 0) {
        const lat = data[0].lat;
        const lon = data[0].lon;

        map.setView([lat, lon], 15);
        L.marker([lat, lon]).addTo(map)
          .bindPopup(`Resultado: ${query}`)
          .openPopup();
      } else {
        alert('Local não encontrado. Tente outro endereço!');
      }
    })
    .catch(error => {
      console.error('Erro na busca:', error);
      alert('Erro ao buscar localização.');
    });
});

// ========== FORMULÁRIO DE MANUTENÇÃO ==========
const form = document.getElementById("form-manutencao");
const lista = document.getElementById("lista-manutencoes");

// Carrega tarefas do banco ao carregar a página
document.addEventListener("DOMContentLoaded", async () => {
  try {
    const response = await fetch('http://localhost:3000/tarefas');
    const tarefas = await response.json();
    tarefas.forEach(tarefa => adicionarManutencaoNaLista(tarefa));
  } catch (error) {
    console.error('Erro ao carregar tarefas:', error);
    alert('Erro ao carregar dados do servidor.');
  }
});

form.addEventListener("submit", async function (e) {
  e.preventDefault();

  // Captura os dados do formulário
  const titulo = document.getElementById("titulo").value.trim();
  const descricao = document.getElementById("descricao").value.trim();
  const localizacao = document.getElementById("localizacao").value.trim();

  // Verifica se todos os campos obrigatórios foram preenchidos
  if (!titulo || !descricao || !localizacao) {
    alert('Por favor, preencha todos os campos obrigatórios!');
    return;
  }

  // Envia pro back-end
  try {
    const response = await fetch('http://localhost:3000/tarefas', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        titulo: titulo,  // Adicionando o título
        descricao: descricao,  // Adicionando a descrição
        localizacao: localizacao,  // Adicionando a localização
        usuario_id: 1 // ⚠️ Ajuste conforme o ID real do usuário logado
      })
    });

    const result = await response.json();

    if (response.ok) {
      // Adiciona na tela com status "Em andamento"
      adicionarManutencaoNaLista({
        titulo: titulo,  // Agora estamos passando título
        descricao: descricao,
        localizacao: localizacao,
        status: "Em andamento"  // Status "Em andamento" automaticamente
      });

      form.reset();
    } else {
      alert(result.erro || "Erro ao salvar a tarefa.");
    }
  } catch (error) {
    console.error('Erro ao enviar tarefa:', error);
    alert("Erro ao enviar. Verifique sua conexão.");
  }
});

// ========== ADICIONA ITEM NA TELA ==========
function adicionarManutencaoNaLista(tarefa) {
  const item = document.createElement("li");
  item.style.position = "relative";
  item.style.paddingBottom = "24px";

  // Exibe o título, descrição, localização e status
  item.innerHTML = `
    <strong>${tarefa.titulo}</strong><br/>
    <em>${tarefa.localizacao}</em><br/>
    <p>${tarefa.descricao}</p>
    <span class="status-label" style="color: #f39c12;">
      ${tarefa.status || 'Em andamento'}
    </span>
  `;

  // Verifica se o usuário é administrador e se deve adicionar o botão de alterar status
  if (isAdmin()) {
    const botaoAlterarStatus = document.createElement("button");
    botaoAlterarStatus.classList.add("btn-alterar-status");
    botaoAlterarStatus.textContent = "Alterar Status";
    botaoAlterarStatus.onclick = () => alterarStatus(tarefa.id);

    item.appendChild(botaoAlterarStatus);
  }

  lista.appendChild(item);
}

// ========== ALTERAR STATUS DA TAREFA ==========
async function alterarStatus(tarefaId) {
  // Verificar se o usuário é administrador antes de permitir alteração
  if (!isAdmin()) {
    alert("Você não tem permissão para alterar o status desta tarefa.");
    return;
  }

  try {
    // Atualizar o status no servidor
    const response = await fetch(`http://localhost:3000/tarefas/${tarefaId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        status: 'Concluído'
      })
    });

    const result = await response.json();

    if (response.ok) {
      // Atualizar o status na tela
      const tarefaElement = document.querySelector(`[data-id="${tarefaId}"]`);
      const statusLabel = tarefaElement.querySelector('.status-label');
      statusLabel.textContent = 'Concluído';
      statusLabel.style.color = '#28a745';  // Cor verde para concluído
    } else {
      alert(result.erro || "Erro ao atualizar status.");
    }
  } catch (error) {
    console.error('Erro ao alterar status:', error);
    alert("Erro ao alterar status. Verifique sua conexão.");
  }
}

// ========== FUNÇÃO DE VERIFICAÇÃO DE ADMIN ==========
function isAdmin() {
  // Essa função deve verificar se o usuário é um administrador. Aqui está um exemplo fictício:
  const usuario = { id: 1, role: 'admin' };  // Aqui você pode integrar com a autenticação do seu sistema
  return usuario.role === 'admin';
}
