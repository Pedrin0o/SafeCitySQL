const express = require('express');
const cors = require('cors');
const mysql = require('mysql2'); // Importando o MySQL
const bcrypt = require('bcrypt'); // Para criptografar a senha
const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Conexão com o banco de dados MySQL
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'manutencao' // Certifique-se de que o banco de dados correto está sendo usado
});

db.connect((err) => {
  if (err) {
    console.error('Erro ao conectar no MySQL:', err);
    return;
  }
  console.log('🗄️  Conectado ao banco de dados MySQL!');
});

// Rota de cadastro
app.post('/cadastro', async (req, res) => {
  const { data_nascimento, email, password, confirmPassword, cpf } = req.body;

  // Verificações básicas
  if (!data_nascimento || !email || !password || !confirmPassword || !cpf) {
    return res.status(400).json({ message: 'Preencha todos os campos!' });
  }

  if (password !== confirmPassword) {
    return res.status(400).json({ message: 'As senhas não coincidem!' });
  }

  try {
    // Verificando se o email já existe
    const [rows] = await db.promise().query('SELECT * FROM usuarios WHERE email = ?', [email]);

    if (rows.length > 0) {
      return res.status(400).json({ message: 'Email já cadastrado!' });
    }

    // Criptografando a senha
    const hashedPassword = await bcrypt.hash(password, 10);

    // Inserindo no banco
    const query = 'INSERT INTO usuarios (data_nascimento, email, senha, cpf) VALUES (?, ?, ?, ?)';
    db.query(query, [data_nascimento, email, hashedPassword, cpf], (err, result) => {
      if (err) {
        console.error('Erro ao cadastrar usuário:', err);
        return res.status(500).json({ message: 'Erro interno ao cadastrar.' });
      }
      return res.status(200).json({ message: 'Cadastro realizado com sucesso!' });
    });

  } catch (error) {
    console.error('Erro ao realizar o cadastro:', error);
    res.status(500).json({ message: 'Erro interno ao processar o cadastro.' });
  }
});

// Rota de login
app.post('/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: 'Preencha todos os campos!' });
  }

  const query = 'SELECT * FROM usuarios WHERE email = ?';
  db.query(query, [email], async (err, results) => {
    if (err) {
      console.error('Erro ao buscar usuário:', err);
      return res.status(500).json({ message: 'Erro interno ao fazer login.' });
    }

    if (results.length === 0) {
      return res.status(401).json({ message: 'Usuário não encontrado.' });
    }

    const usuario = results[0];
    const passwordMatch = await bcrypt.compare(password, usuario.senha); // Correção para 'senha' no banco

    if (!passwordMatch) {
      return res.status(401).json({ message: 'Senha incorreta.' });
    }

    return res.status(200).json({ message: 'Login realizado com sucesso!' });
  });
});

// Iniciando servidor
app.listen(PORT, () => {
  console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
});
