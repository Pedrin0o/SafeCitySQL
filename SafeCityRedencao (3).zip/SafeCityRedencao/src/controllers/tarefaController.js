const db = require('../config/db');

// Cria nova tarefa
exports.criarTarefa = (req, res) => {
  const { titulo, descricao, localizacao, usuario_id } = req.body;

  // Verifica se todos os campos obrigatórios foram enviados
  if (!titulo || !descricao || !localizacao || !usuario_id) {
    console.error('Dados incompletos:', req.body);
    return res.status(400).json({ erro: 'Faltando dados obrigatórios.' });
  }

  // Comando SQL para inserir uma nova tarefa
  const query = 'INSERT INTO tarefas (titulo, descricao, localizacao, usuario_id) VALUES (?, ?, ?, ?)';
  db.query(query, [titulo, descricao, localizacao, usuario_id], (err, result) => {
    if (err) {
      console.error('Erro ao criar tarefa:', err);
      return res.status(500).json({ erro: 'Erro ao criar tarefa.' });
    }

    res.status(201).json({ msg: 'Tarefa criada com sucesso!', id: result.insertId });
  });
};

// Lista todas as tarefas
exports.listarTarefas = (req, res) => {
  const query = 'SELECT id, titulo, descricao, localizacao, status FROM tarefas';

  db.query(query, (err, results) => {
    if (err) {
      console.error('Erro ao listar tarefas:', err);
      return res.status(500).json({ erro: 'Erro ao listar tarefas.' });
    }

    res.json(results); // Retorna as tarefas no formato JSON
  });
};

// Atualiza o status de uma tarefa
exports.atualizarStatus = (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  // Verifica se o status é válido
  if (!['em andamento', 'concluida'].includes(status)) {
    return res.status(400).json({ erro: 'Status inválido.' });
  }

  const query = 'UPDATE tarefas SET status = ? WHERE id = ?';
  db.query(query, [status, id], (err, result) => {
    if (err) {
      console.error('Erro ao atualizar status:', err);
      return res.status(500).json({ erro: 'Erro ao atualizar status.' });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ erro: 'Tarefa não encontrada.' });
    }

    res.json({ msg: 'Status atualizado com sucesso!' });
  });
};

// Deleta uma tarefa
exports.deletarTarefa = (req, res) => {
  const { id } = req.params;

  const query = 'DELETE FROM tarefas WHERE id = ?';
  db.query(query, [id], (err, result) => {
    if (err) {
      console.error('Erro ao deletar tarefa:', err);
      return res.status(500).json({ erro: 'Erro ao deletar tarefa.' });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ erro: 'Tarefa não encontrada.' });
    }

    res.json({ msg: 'Tarefa deletada com sucesso!' });
  });
};
