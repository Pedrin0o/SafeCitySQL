const express = require('express');
const router = express.Router();
const controller = require('../controllers/tarefaController');

// Rota para criar nova tarefa
router.post('/', controller.criarTarefa);

// Listar todas
router.get('/', controller.listarTarefas);

// Atualizar status
router.put('/:id', controller.atualizarStatus);

// Deletar
router.delete('/:id', controller.deletarTarefa);

module.exports = router;
